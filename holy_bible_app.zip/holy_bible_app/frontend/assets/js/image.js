const imageInput = document.getElementById("imageInput");
const uploadBox = document.getElementById("uploadBox");
const previewBox = document.getElementById("preview");
const removeImageBtn = document.getElementById("removeImageBtn");
const imageDesc = document.getElementById("imageDesc");
const uploadBtn = document.getElementById("uploadBtn");
const uploadStatus = document.getElementById("uploadStatus");

let base64Image = "";

// Preview image (SMALL)
imageInput.addEventListener("change", function (e) {
    const file = e.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = function () {
        base64Image = reader.result;

        uploadBox.classList.add("has-image");
        previewBox.innerHTML = `<img src="${base64Image}" />`;
        previewBox.style.display = "block";
    };
    reader.readAsDataURL(file);
});

// Remove image
removeImageBtn.addEventListener("click", function () {
    base64Image = "";
    imageInput.value = "";
    previewBox.innerHTML = "";
    previewBox.style.display = "none";
    uploadBox.classList.remove("has-image");
});

// Upload
uploadBtn.addEventListener("click", async function () {
    if (!base64Image) {
        alert("Please select an image.");
        return;
    }

    const payload = {
        description: imageDesc.value.trim(),
        poster_photo_path1: base64Image
    };

    uploadBtn.disabled = true;
    uploadStatus.textContent = "Uploading...";

    try {
        const res = await fetch("https://dev.tamilbibleapp.com/api_dev/poster_photo_api", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload),
        });

        const data = await res.json();

        if (data.user_stat === 1) {
            alert("Upload Successful!\n\nResponse:\n" + JSON.stringify(data, null, 4));

            // reset
            base64Image = "";
            imageInput.value = "";
            imageDesc.value = "";
            previewBox.innerHTML = "";
            previewBox.style.display = "none";
            uploadBox.classList.remove("has-image");

        } else {
            alert("Upload failed!\n\n" + JSON.stringify(data, null, 4));
        }
    } catch (err) {
        alert("Error: " + err.message);
    }

    uploadBtn.disabled = false;
    uploadStatus.textContent = "";
});
