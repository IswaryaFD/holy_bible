// ======================= FORMAT DATE & TIME =========================
function formatDateTime(isoString) {
    const date = new Date(isoString);

    const day = String(date.getDate()).padStart(2, "0");
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const year = date.getFullYear();

    let hours = date.getHours();
    let minutes = String(date.getMinutes()).padStart(2, "0");

    let ampm = hours >= 12 ? "PM" : "AM";
    hours = hours % 12 || 12; // convert to 12-hour format

    return `${day}/${month}/${year} ${hours}:${minutes} ${ampm}`;
}



// ======================= LOAD DATA FROM API =========================
async function loadData(){
    const url = "https://dev.tamilbibleapp.com/api_dev/login_api";

    const payload = {
        key: "list"
    };

    try{
        const res = await fetch(url, {
            method: "POST",
            mode: "cors",
            credentials: "omit",
            headers: {
                "Accept": "application/json",
                "Content-Type": "application/json"
            },
            body: JSON.stringify(payload)
        });

        if (!res.ok) {
            throw new Error("Server returned status " + res.status);
        }

        const data = await res.json();
        console.log("API Response:", data);

        if(data.user_stat !== 1){
            alert("Failed to load list");
            return;
        }

        const list = data.login_list;

        let html = `
            <table>
                <tr>
                    <th>ID</th>
                    <th>Email</th>
                    <th>Password</th>
                    <th>Created Date</th>
                    <th>Updated Date</th>
                    <th>Status</th>
                </tr>
        `;

        list.forEach(item=>{
            html += `
                <tr>
                    <td>${item.login_id}</td>
                    <td>${item.login_email}</td>
                    <td>${item.login_password}</td>
                    <td>${formatDateTime(item.login_created_dt)}</td>
                    <td>${formatDateTime(item.login_updated_dt)}</td>
                    <td class="status ${
                        item.login_active_ind == 1 ? 'active' : 'inactive'
                    }">
                        ${item.login_active_ind == 1 ? 'Active' : 'Inactive'}
                    </td>
                </tr>
            `;
        });

        html += `</table>`;
        document.getElementById("listContainer").innerHTML = html;

    } catch(err){
        console.error("FETCH ERROR:", err);
        alert("Error: " + err.message);
    }
}



// ======================= AUTO LOAD WHEN PAGE OPENS =========================
window.addEventListener("DOMContentLoaded", loadData);
