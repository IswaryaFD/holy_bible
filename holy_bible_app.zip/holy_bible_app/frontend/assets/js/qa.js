const qInput = document.getElementById('qInput');
const aInput = document.getElementById('aInput');
const addQA = document.getElementById('addQA');
const qaList = document.getElementById('qaList');

let items = [];

function render(){
  qaList.innerHTML = items.map(it => `<div class="qa-item"><h4>${escapeHtml(it.q)}</h4><p>${escapeHtml(it.a)}</p></div>`).join('');
}
function escapeHtml(s){ return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }

addQA.addEventListener('click', ()=>{
  const q = qInput.value.trim(); const a = aInput.value.trim();
  if(!q || !a) return alert('Both fields required');
  items.unshift({q,a});
  qInput.value=''; aInput.value='';
  render();
});
