const verseImageInput = document.getElementById('verseImageInput');
const verseText = document.getElementById('verseText');
const saveVerse = document.getElementById('saveVerse');
const versePreview = document.getElementById('versePreview');
let verseFile = null;

verseImageInput.addEventListener('change',(e)=>{
  verseFile = e.target.files[0];
  if(verseFile) versePreview.innerHTML = `<img src="${URL.createObjectURL(verseFile)}" style="max-width:220px;border-radius:8px">`;
});

saveVerse.addEventListener('click', async ()=>{
  const text = verseText.value.trim();
  if(!text){ alert('Enter verse text'); return; }
  const API_BASE = 'http://127.0.0.1:8000/api';
  const form = new FormData();
  form.append('text', text);
  if(verseFile) form.append('file', verseFile);
  try {
    const res = await fetch(`${API_BASE}/bible-verse`, { method:'POST', body: form });
    if(!res.ok) throw new Error('Saving failed');
    const data = await res.json();
    alert('Saved verse id: '+ data.id);
    verseText.value = '';
    versePreview.innerHTML = '';
  } catch(err){ console.error(err); alert('Error: '+err.message); }
});
